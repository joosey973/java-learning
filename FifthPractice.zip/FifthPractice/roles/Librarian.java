package FifthPractice.roles;

public interface Librarian {
    void orderBook(String bookTitle, Supplier supplier);
}