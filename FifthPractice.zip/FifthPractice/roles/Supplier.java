package FifthPractice.roles;

public interface Supplier {
    void bringBook(String bookTitle, Librarian librarian);
}