package FifthPractice.roles;

public interface Administrator {
    void findAndGiveBook(String bookTitle, Reader reader);
    void overdueNotification(Reader reader);
}