package FifthPractice.roles;

public interface Reader {
    void takeBook(String bookTitle, Administrator admin);
    void returnBook(String bookTitle, Administrator admin);
}